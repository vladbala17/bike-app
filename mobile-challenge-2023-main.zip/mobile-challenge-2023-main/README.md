# Bike App Challenge
Specifications for the Bike App Challenge. Welcome and have fun! 

## Android Challenge
Check the Android Challenge folder.
- **Bike App Android.pdf** contains the app specification, flow and each screen's details.
- **Android Resources** contains your resouce files.

## iOS Challenge
Check the iOS Challenge folder.
- **Bike App iOS.pdf** contains the app specification, flow and each screen's details.
- **iOS Resources** contains your resouce files.
